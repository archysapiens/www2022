<?php
$link = mysqli_connect('200.52.83.41','archysof_dvlp','archysoft','archysoft_com_mx_dvlp');
  /* check connection */
  if (mysqli_connect_errno()) {
      printf("Error de conexión: %s\n", mysqli_connect_error());
      exit();
  }
?>



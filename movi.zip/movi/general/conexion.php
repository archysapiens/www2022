<?php
//Para establecer la conexión con el servidor y la base de datos


$conn=mysql_connect("200.52.83.41","archysof_dvlp","archysoft");
	mysql_select_db("archysoft_com_mx_dvlp",$conn);


?>


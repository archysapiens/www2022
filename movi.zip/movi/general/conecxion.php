<?php

$localhost="localhost";
$user="root";
$passwd="";
$db_name="ecshdv";
$link = mysqli_connect($localhost,$user,$passwd, $db_name);

/**
$localhost="200.52.83.41";
$user="archysof_dvlp";
$passwd="archysoft";
$db_name="archysoft_com_mx_dvlp";
$link = mysqli_connect($localhost,$user,$passwd, $db_name);

echo "estoy en conecxion con datos anteriores";
**/
?>